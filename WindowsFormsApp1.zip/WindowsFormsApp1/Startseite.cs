﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Startseite : Form
    {
        
        public Startseite()
        {
            InitializeComponent();
        }
        int Modus;

       

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (Modus == 2)
            {
                Benutzeroberfläche form = new Benutzeroberfläche(1);
                form.Show();

            }
            if (Modus == 1)
            {

            }
            
            
            
          
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Benutzeroberfläche form = new Benutzeroberfläche(0);
            form.ShowDialog();
           
            
            
            
            
            
          

        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;
            Modus = 2;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.Enabled = false;
            Modus = 1;

        }
    }
}
